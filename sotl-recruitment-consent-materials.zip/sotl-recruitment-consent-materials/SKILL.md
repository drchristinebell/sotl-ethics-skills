---
name: sotl-recruitment-consent-materials
description: Use when a Scholarship of Teaching and Learning researcher needs recruitment emails, oral scripts, slides, or a Letter of Information and Consent for an ethics application.
---

# Recruitment and Consent Materials for Scholarship of Teaching and Learning Studies

Help a Canadian academic researcher prepare recruitment and consent materials for a Scholarship of Teaching and Learning study. All materials must comply with the Tri-Council Policy Statement: Ethical Conduct for Research Involving Humans, second edition (2018).

The researcher is usually both the course instructor and the lead researcher. Every material must be worded so students do not feel pressured to participate. Participation must be framed as entirely voluntary, and every material must state that choosing not to participate will have no effect on grades, academic standing, or the student's relationship with the instructor.

## Step 1: Collect the study details

Ask the researcher for any of the following that they have not already provided. Ask for all missing fields in one message, not one at a time. If a field does not apply, record it as not applicable. Never invent a study detail; if the researcher wants a draft before everything is filled in, use a placeholder in [square brackets] that names what is missing.

- Instructor-researcher name and title
- Institution
- Course name and number
- Study title, in plain language
- Purpose of the study, in one or two plain-language sentences
- What participants will be asked to do, activity by activity
- Time commitment
- When participation will take place
- Where or how participation takes place
- Third-party recruiter name and role
- How participants will access the Letter of Information and Consent (for example, a link in an email or a QR code in class)
- Remuneration, or that none is offered
- What happens to a participant's data if they withdraw
- How data will be stored and protected (access, de-identification, destruction)
- Who will have access to identifiable data, and when data will be de-identified
- Research Ethics Board file number, or not yet assigned
- Version date for the materials
- Contact for participant questions (name and email)
- Research Ethics Board contact for participant rights
- Which outputs are needed: third-party recruitment email, in-class oral recruitment script, one-slide recruitment slide, Letter of Information and Consent
- Whether consent will be given on paper or online

## Step 2: Flag ethics concerns before drafting

Before writing anything, briefly flag any detail that a Research Ethics Board reviewer is likely to question, and suggest what to change. Common examples:
- The instructor recruits directly, or will know who participated before final grades are submitted.
- Data collection or access to identifiable data happens before final grades are submitted, with no mitigation described.
- Remuneration is large enough to feel like an inducement, or is described as anything other than a thank-you.
- Withdrawal terms are unclear, or the point after which data cannot be withdrawn is not stated.
- Activities or discussions go beyond what students encounter in everyday life, including their usual course activities, but risk is described as minimal.
- Consent method is not stated, or the consent process allows data collection before consent is given.

Do not soften or understate risk in any material. If the researcher's description of risk seems too low for the activities described, say so.

## Step 3: Draft the requested outputs

Tone for all materials: warm, clear, plain language at approximately a Grade 8 reading level. No jargon. Write in complete sentences and paragraphs unless the format calls for bullet points. Spell out terms in full. Do not use em dashes. The final text of each output should be clean and ready to paste, with no markdown symbols.

### Third-party recruitment email
Written in third person. Neutral subject line. States who is sending it and why. Describes purpose, participation, time commitment, and timing. States that participation is voluntary with no academic impact. Explains how to access the Letter of Information and Consent. Describes remuneration as a thank-you. Gives a contact for questions. Closes with the third-party recruiter's details and the version date.

### In-class oral recruitment script
Written in first person for the third-party recruiter, 2 to 3 minutes when read aloud. Introduces the speaker. Describes the study and what participation involves. States that participation is voluntary with no academic impact. Explains access to the Letter of Information and Consent by QR code or link. Invites questions. Informational and neutral throughout, never persuasive.

### Recruitment slide
One slide. Neutral title. Four to five bullet points covering purpose, participation, time, voluntariness, and access to the Letter of Information and Consent. A clearly labeled placeholder for the QR code. Include alternative text for the QR code that gives the link in words.

### Letter of Information and Consent
Include these sections, in this order:
1. Document title
2. Study title
3. Invitation
4. Purpose
5. Researcher information
6. What participation involves
7. Time and timing
8. Voluntary participation and no academic impact
9. Dual role disclosure and how it is managed
10. Risks
11. Benefits
12. Confidentiality and data management
13. Remuneration and withdrawal policy
14. How to withdraw
15. How results will be shared
16. Research Ethics Board information
17. Consent statement
18. Signature lines for paper consent, or online consent wording (for example, a statement that proceeding or selecting a button indicates consent) if consent is online

## Step 4: Check consistency

Before presenting the outputs, compare them against each other and against the study details. These must be identical across every output: study purpose, participation activities, time commitment, timing, voluntariness language, remuneration, access method for the Letter of Information and Consent, contact information, and version date.

Fix any inconsistency before presenting. Then report the result honestly at the end: either confirm that all details are consistent across outputs, or list anything that could not be made consistent and why (for example, a field the researcher still needs to fill in).

## Step 5: Deliver

Present each requested output under its own heading, followed by:
- A short list of any [square bracket] placeholders the researcher still needs to fill in.
- The consistency result from Step 4.

If the researcher wants an editable document to share with co-investigators or attach to the ethics application, offer to put the materials into one.

---
name: ethics-reviewer-response
description: Use when a researcher needs to respond to Research Ethics Board reviewer comments on an ethics application and wants a response letter plus an action item checklist.
---

# Responding to Research Ethics Board Reviewer Comments

Help a Scholarship of Teaching and Learning researcher respond clearly and completely to reviewer comments on an ethics application, and leave them with a concrete list of tasks to finish before resubmitting.

## Step 1: Gather the inputs

You need:
1. The reviewer comments, in full.
2. The relevant sections of the ethics application (at minimum, any section a comment refers to).
3. Optional but helpful: the study procedures section, consent form, recruitment materials, and any institution-specific resubmission instructions.

If the comments are missing, ask for them before doing anything else. If application sections are missing, proceed with what you have and use placeholders where you need detail.

## Step 2: Check for participant data before working

Research participant data should never be entered into generative artificial intelligence tools. Before working with any pasted material, scan it for participant data or identifying information (names, student numbers, email addresses, transcripts, survey responses, or anything that could identify a participant).

If you find any, stop. Tell the researcher what you found and where, ask them to remove it and paste a cleaned version, and do not quote, summarize, or reuse the identifying content in your reply. Remind them to check their institution's and their research team's rules on generative artificial intelligence use. Application text, consent form templates, and reviewer comments are fine to work with.

## Step 3: Organize the comments

- Number every comment in the order the reviewer gave it, keeping the reviewer's own numbering if there is one.
- Label each as a required change, a request for clarification, or a suggestion.
- Group comments that address the same underlying issue, and flag any that conflict with each other.

## Step 4: Name the underlying concern

For each comment, state in one plain-language sentence what the reviewer is actually worried about (for example: participant risk, power differential between instructor and students, consent timing, voluntariness, privacy, data storage, or secondary use of data). Responses should address the concern, not only the wording.

## Step 5: Draft the responses

For each comment:
- State what was changed and where it now appears in the revised application (section and page), or, if no change is being made, give a clear and respectful rationale.
- Use a respectful, professional, non-defensive tone. Thank reviewers once at the top of the letter, not in every response.
- Never invent study details. Where information is needed that the researcher has not provided, insert a placeholder in [square brackets] describing exactly what to fill in.
- Where a change is needed in the application itself, draft the revised application text so the researcher can paste it in.

### Risk
Never soften, minimize, or remove any description of risk to participants. If a reviewer raised a concern about risk, help the researcher describe the risk accurately and explain how it will be managed. If the application appears to understate risk (for example, tasks or discussions that go beyond what students encounter in everyday life, including their usual course activities, but are described as minimal risk), point this out even if no reviewer did.

### Consent
Only reference consent methods that are in the approved or proposed procedures. Do not suggest alternatives, such as verbal consent, unless the researcher is deliberately adding them to the protocol in this revision.

## Step 6: Check consistency across the application

List every other place in the application that must change because of these revisions (for example, a changed recruitment timeline may also affect the consent form, recruitment script, and study procedures). Remind the researcher that the overall study procedures summary should be revised last so it reflects every other change.

## Step 7: Produce the output

Deliver three parts, in this order:

1. Response letter. A short opening thanking the reviewers, then a table with three columns: Reviewer comment (verbatim or closely summarized), Response, Location of change. One row per comment.
2. Revised application text. For each changed passage, the section name followed by the new text, ready to paste.
3. Action item checklist. A numbered list of every task the researcher must complete before resubmitting: documents to revise, information to gather, team members to consult, placeholders to fill in, and any questions to raise with the ethics officer. End with: "Fill in all [square bracket] placeholders and revise the overall study procedures last."

If the researcher wants a document they can edit or share, offer to put the response letter and checklist into one.

## Style

- Spell out terms in full; do not use abbreviations or acronyms in your explanations.
- Do not use em dashes.
- Keep explanations brief and practical.
